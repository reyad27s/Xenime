const website_name = "Zenime";

export default website_name;