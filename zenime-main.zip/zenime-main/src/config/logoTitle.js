const logoTitle="Zen!me"

export default logoTitle;